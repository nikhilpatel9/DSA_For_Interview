<img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/String_example.png" width="600" height="250">

# DP On Strings : :triangular_flag_on_post:

<h1>Questions</h1>
<table id="example" class="SectionTable display">
    <thead>
        <th>Problem Name</th>
    </thead>
    <tbody>
        <tr>
            <td>
                <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/DP%20on%20Strings/Palindromic%20Substrings.cpp"> Palindromic Substrings (Leetcode-647) </a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/DP%20on%20Strings/Printing%20Longest%20Common%20Subsequence.cpp"> Printing Longest Common Subsequence (GfG) </a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/DP%20on%20Strings/Shortest%20Common%20Supersequence.cpp"> Shortest Common Supersequence (GfG) </a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/DP%20on%20Strings/Print%20Shortest%20Common%20Supersequence.cpp"> Print Shortest Common Supersequence (Leetcode-1092) </a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/DP%20on%20Strings/Freedom%20Trail.cpp"> Freedom Trail (Leetcode-514) </a>
            </td>
        </tr>
        <tr>
            <td>
                <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/DP%20on%20Strings/Palindrome%20Partitioning%20II.cpp"> Palindrome Partitioning II (Leetcode-132) </a>
            </td>
        </tr>
    </tbody>
</table>
