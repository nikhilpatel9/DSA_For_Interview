<img src="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/icon.png" align="right" /> <a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://camo.githubusercontent.com/82b228a3648bf44fc1163ef44c62fcc60081495e/68747470733a2f2f73332e616d617a6f6e6177732e636f6d2f6769746875622f726962626f6e732f666f726b6d655f6c6566745f7265645f6161303030302e706e67" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://cdn-images-1.medium.com/max/1200/1*Y1IuqrkoDWLlfz_BSaesGQ.jpeg" width="600" height="250">

# LIS & Variants : :triangular_flag_on_post:

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
	<thead>
      		<th>Problem Name</th>
	</thead>
	<tbody>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Longest%20Increasing%20Subsequence.cpp"> Longest Increasing Subsequence (Leetcode - 300)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Maximum%20Length%20of%20Pair%20Chain.cpp"> Maximum Length of Pair Chain (Leetcode - 646)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20&%20Variants/Russian%20Doll%20Envelopes.cpp"> Russian Doll Envelopes (Leetcode-354)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Longest%20String%20Chain.cpp"> Longest String Chain (Leetcode-1048)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Build%20Array%20Where%20You%20Can%20Find%20The%20Maximum%20Exactly%20K%20Comparisons.cpp"> Build Array Where You Can Find The Maximum Exactly K Comparisons (Leetcode-1420)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Maximum%20Balanced%20Subsequence%20Sum.cpp"> Maximum Balanced Subsequence Sum (Leetcode-2926)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Largest%20Divisible%20Subset.cpp"> Largest Divisible Subset (Leetcode-368)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Longest%20Ideal%20Subsequence.cpp"> Longest Ideal Subsequence (Leetcode-2370)</a>
			</td>
		</tr>
		<tr>
        		<td>
				<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/DP/LIS%20%26%20Variants/Minimum%20Number%20of%20Removals%20to%20Make%20Mountain%20Array.cpp"> Minimum Number of Removals to Make Mountain Array (Leetcode - 1671)</a>
			</td>
		</tr>
	</tbody>
</table>
