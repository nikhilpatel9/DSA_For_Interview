<a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://github.blog/wp-content/uploads/2008/12/forkme_left_orange_ff7600.png?resize=149%2C149" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Difference%20Array%20Technique/Amazon%2C%20Flipkart%2C%20ABCO.png" width="600" height="250">

# Difference Array Technique : :triangular_flag_on_post:

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
		<thead>
      <th>Problem Name</th>
		</thead>
		<tbody>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Difference%20Array%20Technique/Range%20Addition.cpp"> Range Addition (Leetcode - 370)</a>
				</td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Difference%20Array%20Technique/Shifting%20Letters%20II.cpp"> Shifting Letters II (Leetcode - 2381)</a>
				</td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Difference%20Array%20Technique/Zero%20Array%20Transformation%20II.cpp"> Zero Array Transformation II (Leetcode - 3356)</a>
				</td>
      			</tr>
		</tbody>
</table>
