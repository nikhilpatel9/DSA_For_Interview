<a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://camo.githubusercontent.com/82b228a3648bf44fc1163ef44c62fcc60081495e/68747470733a2f2f73332e616d617a6f6e6177732e636f6d2f6769746875622f726962626f6e732f666f726b6d655f6c6566745f7265645f6161303030302e706e67" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://helloacm.com/wp-content/uploads/2019/12/merge-intervals.jpg" width="600" height="250">

# Arrays/Intervals_Based_Qns : :triangular_flag_on_post:

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
		<thead>
      <th>Problem Name</th>
		</thead>
		<tbody>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Merge%20Intervals.cpp">Merge Intervals (Leetcode-56)</a>
				</td>
			</tr>
      			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Leetcode-August-Challenge-2020/blob/master/Non-overlapping%20Intervals%20(C%2B%2B)">Non-overlapping Intervals (Leetcode-435)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Insert%20Interval.cpp">Insert Interval (2 approaches) (Leetcode-57)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Meeting%20Rooms.cpp">Meeting Rooms (Leetcode-252)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Meeting%20Rooms%20II.cpp">Meeting Rooms II (Leetcode-253)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Find%20Right%20Interval.cpp">Find Right Interval (4 approaches) (Leetcode-436)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Car%20Pooling%20(2%20approaches)">Car Pooling (2 approaches) (Leetcode-1094)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Remove%20Covered%20Intervals">Remove Covered Intervals (Leetcode-1288)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Meeting_Scheduler.cpp">Meeting Scheduler (Leetcode-1229)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Greedy/Non-overlapping%20Intervals.cpp">Non-overlapping Intervals (Leetcode-435) (Falls under Greedy Category as well)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Greedy/Minimum%20Number%20of%20Arrows%20to%20Burst%20Balloons.cpp">Minimum Number of Arrows to Burst Balloons (3 approaches) (Leetcode-452) (Falls under Greedy Category as well)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/The%20Number%20of%20the%20Smallest%20Unoccupied%20Chair.cpp">The Number of the Smallest Unoccupied Chair (Leetcode-1942)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Interval%20List%20Intersections.cpp">Interval List Intersections (Leetcode-986)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Data%20Stream%20as%20Disjoint%20Intervals.cpp">Data Stream as Disjoint Intervals (Leetcode-352)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Maximum%20Number%20of%20Events%20That%20Can%20Be%20Attended%20II.cpp"> Maximum Number of Events That Can Be Attended II (Leetcode-1751)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Meeting%20Rooms%20III.cpp"> Meeting Rooms III (Leetcode-2402)</a>
				</td>
			</tr>
						<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/My%20Calendar%20I.cpp">My Calendar I (Leetcode-729)</a>
				</td>
			</tr>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/My%20Calendar%20II.cpp"> My Calendar II (Leetcode-731)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Divide%20Intervals%20Into%20Minimum%20Number%20of%20Groups.cpp"> Divide Intervals Into Minimum Number of Groups (Leetcode - 2406)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Two%20Best%20Non-Overlapping%20Events.cpp"> Two Best Non-Overlapping Events (Leetcode - 2054)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Special%20Array%20II.cpp"> Special Array II (Leetcode - 3152)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Maximum%20Beauty%20of%20an%20Array%20After%20Applying%20Operation.cpp"> Maximum Beauty of an Array After Applying Operation (Leetcode - 2779)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Count%20Days%20Without%20Meetings.cpp"> Count Days Without Meetings (Leetcode - 3169)</a>
				</td>
			</tr>
			<tr>
        			<td>
					<a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Intervals_Based_Qn/Check%20if%20Grid%20can%20be%20Cut%20into%20Sections.cpp"> Check if Grid can be Cut into Sections (Leetcode - 3394)</a>
				</td>
			</tr>
		</tbody>
</table>
