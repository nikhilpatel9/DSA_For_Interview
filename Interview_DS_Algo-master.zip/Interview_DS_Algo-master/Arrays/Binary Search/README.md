<img src="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/icon.png" align="right" /><a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://github.blog/wp-content/uploads/2008/12/forkme_left_orange_ff7600.png?resize=149%2C149" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://www.tutorialspoint.com/data_structures_algorithms/images/binary_search_algorithm.jpg" width="600" height="250">

# Arrays/Binary Search : :triangular_flag_on_post:

When to use what Binary Search - <a href = "https://leetcode.com/discuss/general-discussion/786126/Python-Powerful-Ultimate-Binary-Search-Template.-Solved-many-problems">I will make a video on this resource soon</a>

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
		<thead>
      <th>Problem Name</th>
		</thead>
		<tbody>
			<tr>
          <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20Minimum%20in%20Rotated%20Sorted%20Array.cpp">Find Minimum in Rotated Sorted Array (Leetcode-153)</a>
				  </td>
      </tr>
      <tr>
          <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20Minimum%20in%20Rotated%20Sorted%20Array%20II">Find Minimum in Rotated Sorted Array II (Leetcode-154)</a>
				  </td>
      </tr>
      <tr>
          <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Search%20in%20Rotated%20Sorted%20Array.cpp">Search in Rotated Sorted Array (Leetcode-33)</a>
				  </td>
      </tr>
      <tr>
          <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Search%20in%20Rotated%20Sorted%20Array%20II.cpp">Search in Rotated Sorted Array II (Leetcode-81)</a>
				  </td>
      </tr>
			<tr>
          <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20the%20Smallest%20Divisor%20Given%20a%20Threshold">Find the Smallest Divisor Given a Threshold (Leetcode-1283)</a>
				  </td>
      </tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/The%20K%20Weakest%20Rows%20in%20a%20Matrix.cpp">The K Weakest Rows in a Matrix (Leetcode-1337)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Missing%20Number%20In%20Arithmetic%20Progression">Missing Number In Arithmetic Progression (Leetcode-1228)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20First%20and%20Last%20Position%20of%20Element%20in%20Sorted%20Array.cpp">Find First and Last Position of Element in Sorted Array (Leetcode-34)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20K%20Closest%20Elements.cpp">Find K Closest Elements (Leetcode-658)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Shortest%20Distance%20to%20Target%20Color.cpp">Shortest Distance to Target Color (Leetcode-1182)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Number%20of%20Matching%20Subsequences.cpp">Number of Matching Subsequences (Leetcode-792)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Median%20of%20Two%20Sorted%20Arrays.cpp">Median of Two Sorted Arrays (Leetcode-4)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Capacity%20To%20Ship%20Packages%20Within%20D%20Days.cpp">Capacity To Ship Packages Within D Days (Leetcode-1011)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20the%20Rotation%20Count%20in%20Rotated%20Sorted%20array.cpp">Find the Rotation Count in Rotated Sorted array</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Single%20Element%20in%20a%20Sorted%20Array.cpp">Single Element in a Sorted Array (Leetcode-540)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Search%20a%202D%20Matrix.cpp">Search a 2D Matrix (Leetcode-74)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Guess%20Number%20Higher%20or%20Lower.cpp">Guess Number Higher or Lower (Leetcode-374)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimum%20Time%20to%20Complete%20Trips.cpp">Minimum Time to Complete Trips (Leetcode-2187)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Koko%20Eating%20Bananas.cpp">Koko Eating Bananas (Leetcode-875)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Binary%20Search.cpp"> Binary Search (Leetcode-704)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Successful%20Pairs%20of%20Spells%20and%20Potions.cpp"> Successful Pairs of Spells and Potions (Leetcode-2300)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimize%20Maximum%20of%20Array.cpp"> Minimize Maximum of Array (Leetcode-2439)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20Smallest%20Letter%20Greater%20Than%20Target.cpp"> Find Smallest Letter Greater Than Target (Leetcode-744)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Maximum%20Value%20at%20a%20Given%20Index%20in%20a%20Bounded%20Array.cpp"> Maximum Value at a Given Index in a Bounded Array (Leetcode-1802)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimum%20Cost%20to%20Make%20Array%20Equal.cpp"> Minimum Cost to Make Array Equal (Leetcode-2448)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Last%20Day%20Where%20You%20Can%20Still%20Cross.cpp"> Last Day Where You Can Still Cross (Leetcode-1970)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Peak%20Index%20in%20a%20Mountain%20Array.cpp"> Peak Index in a Mountain Array (Leetcode-852)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimum%20Speed%20to%20Arrive%20on%20Time.cpp"> Minimum Speed to Arrive on Time (Leetcode-1870)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Maximum%20Running%20Time%20of%20N%20Computers.cpp"> Maximum Running Time of N Computers (Leetcode-2141)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimize%20the%20Maximum%20Difference%20of%20Pairs.cpp"> Minimize the Maximum Difference of Pairs (Leetcode-2616)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Number%20of%20Flowers%20in%20Full%20Bloom.cpp"> Number of Flowers in Full Bloom (Leetcode-2251)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20in%20Mountain%20Array.cpp"> Find in Mountain Array (Leetcode-1095)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Apply%20Operations%20to%20Maximize%20Frequency%20Score.cpp"> Apply Operations to Maximize Frequency Score (Leetcode-2968)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20the%20Safest%20Path%20in%20a%20Grid.cpp"> Find the Safest Path in a Grid (Leetcode-2812)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Most%20Profit%20Assigning%20Work.cpp"> Most Profit Assigning Work (Leetcode-826)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimum%20Number%20of%20Days%20to%20Make%20m%20Bouquets.cpp"> Minimum Number of Days to Make m Bouquets (Leetcode-1482)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Magnetic%20Force%20Between%20Two%20Balls.cpp"> Magnetic Force Between Two Balls (Leetcode-1552)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Find%20K-th%20Smallest%20Pair%20Distance.cpp"> Find K-th Smallest Pair Distance (Leetcode-719)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Most%20Beautiful%20Item%20for%20Each%20Query.cpp"> Most Beautiful Item for Each Query (Leetcode - 2070)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Count%20the%20Number%20of%20Fair%20Pairs.cpp"> Count the Number of Fair Pairs (Leetcode - 2563)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimum%20Limit%20of%20Balls%20in%20a%20Bag.cpp"> Minimum Limit of Balls in a Bag (Leetcode - 1760)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Maximize%20the%20Minimum%20Game%20Score.cpp"> Maximize the Minimum Game Score (Leetcode - 3449)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Maximize%20the%20Distance%20Between%20Points%20on%20a%20Square.cpp"> Maximize the Distance Between Points on a Square (Leetcode - 3464)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Maximum%20Candies%20Allocated%20to%20K%20Children.cpp"> Maximum Candies Allocated to K Children (Leetcode - 2226)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/House%20Robber%20IV.cpp"> House Robber IV (Leetcode - 2560)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Binary%20Search/Minimum%20Time%20to%20Repair%20Cars.cpp"> Minimum Time to Repair Cars (Leetcode - 2594)</a>
				  </td>
      			</tr>
		</tbody>
</table>
