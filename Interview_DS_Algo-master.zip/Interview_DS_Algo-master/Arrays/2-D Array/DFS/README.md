<img src="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/icon.png" align="right" /><a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://camo.githubusercontent.com/82b228a3648bf44fc1163ef44c62fcc60081495e/68747470733a2f2f73332e616d617a6f6e6177732e636f6d2f6769746875622f726962626f6e732f666f726b6d655f6c6566745f7265645f6161303030302e706e67" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://he-s3.s3.amazonaws.com/media/uploads/9fa1119.jpg" width="600" height="250">
# Arrays/2-D Array/DFS : :triangular_flag_on_post:

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
		<thead>
      <th>Problem Name</th>
		</thead>
		<tbody>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Pacific%20Atlantic%20Water%20Flow">Pacific Atlantic Water Flow (Leetcode-417)</a>
				  </td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Longest_Increasing_Path_in_a_Matrix.cpp">Longest Increasing Path in a Matrix (Leetcode-329)</a>
				  </td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Number%20of%20Closed%20Islands.cpp">Number of Closed Islands (Leetcode-1254)</a>
				  </td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Number%20of%20Enclaves.cpp">Number of Enclaves (Leetcode-1020)</a>
				  </td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Regions%20Cut%20By%20Slashes.cpp"> Regions Cut By Slashes (Leetcode-959)</a>
				  </td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Minimum%20Number%20of%20Days%20to%20Disconnect%20Island.cpp"> Minimum Number of Days to Disconnect Island (Leetcode-1568)</a>
				  </td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/2-D%20Array/DFS/Count%20Unguarded%20Cells%20in%20the%20Grid.cpp"> Count Unguarded Cells in the Grid (Leetcode - 2257)</a>
				  </td>
      			</tr>
		</tbody>
</table>
