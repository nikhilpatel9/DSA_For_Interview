<img src="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/icon.png" align="right" /><a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://github.blog/wp-content/uploads/2008/12/forkme_left_orange_ff7600.png?resize=149%2C149" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Cumulative%20Sum%20Array.jpg" width="600" height="250">

# Arrays/Cumulative_Sum(Prefix Array) : :triangular_flag_on_post:

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
		<thead>
      <th>Problem Name</th>
		</thead>
		<tbody>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Range%20Addition.cpp">Range Addition (Leetcode-370)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Range%20Addition%20II.cpp">Range Addition II (Leetcode-598)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Find%20Pivot%20Index.cpp">Find Pivot Index (Leetcode-724)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Continuous%20Subarray%20Sum.cpp">Continuous Subarray Sum (Leetcode-523)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Minimum%20Average%20Difference.cpp"> Minimum Average Difference (Leetcode-2256)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Longest%20Subsequence%20With%20Limited%20Sum.cpp"> Longest Subsequence With Limited Sum (Leetcode-2389)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/K%20Radius%20Subarray%20Averages.cpp"> K Radius Subarray Averages (Leetcode-2090)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Minimum%20Penalty%20for%20a%20Shop.cpp"> Minimum Penalty for a Shop (Leetcode-2483)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Minimum%20Operations%20to%20Reduce%20X%20to%20Zero.cpp"> Minimum Operations to Reduce X to Zero (Leetcode-1658)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Minimum%20Amount%20of%20Time%20to%20Collect%20Garbage.cpp"> Minimum Amount of Time to Collect Garbage (Leetcode-2391)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Contiguous%20Array.cpp"> Contiguous Array (Leetcode-525)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Count%20Number%20of%20Nice%20Subarrays.cpp"> Count Number of Nice Subarrays (Leetcode-1248)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Make%20Sum%20Divisible%20by%20P.cpp"> Make Sum Divisible by P (Leetcode-1590)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Max%20Chunks%20To%20Make%20Sorted.cpp"> Max Chunks To Make Sorted (Leetcode - 769)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Count%20Vowel%20Strings%20in%20Ranges.cpp"> Count Vowel Strings in Ranges (Leetcode - 2559)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Number%20of%20Ways%20to%20Split%20Array.cpp"> Number of Ways to Split Array (Leetcode - 2270)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Grid%20Game.cpp"> Grid Game (Leetcode - 2017)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Number%20of%20Sub-arrays%20With%20Odd%20Sum.cpp"> Number of Sub-arrays With Odd Sum (Leetcode - 1524)</a>
				  </td>
      			</tr>
			<tr>
          			  <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Cumulative_Sum(Prefix%20Array)/Maximum%20Absolute%20Sum%20of%20Any%20Subarray.cpp"> Maximum Absolute Sum of Any Subarray (Leetcode - 1749)</a>
				  </td>
      			</tr>
		</tbody>
</table>
