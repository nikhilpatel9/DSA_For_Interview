<a href="https://github.com/MAZHARMIK"><img style="position: absolute; top: 0; left: 0; border: 0;" src="https://camo.githubusercontent.com/82b228a3648bf44fc1163ef44c62fcc60081495e/68747470733a2f2f73332e616d617a6f6e6177732e636f6d2f6769746875622f726962626f6e732f666f726b6d655f6c6566745f7265645f6161303030302e706e67" alt="Fork me on GitHub" data-canonical-src="https://s3.amazonaws.com/github/ribbons/forkme_left_red_aa0000.png"></a>
<img src="https://1.bp.blogspot.com/-OalFqOUvJb0/X_hPAYM4rSI/AAAAAAAAAv4/9CumEdhng7MtVyyFjY_K6G0oxWV_0mPtACLcBGAsYHQ/s1000/AdobeStock_190193472_Preview.jpeg" width="600" height="250">

# Arrays/Simulation : :triangular_flag_on_post:

<h1>Questions</h1>
<table id = "example" class="SectionTable display" >
		<thead>
      <th>Problem Name</th>
		</thead>
		<tbody>
			<tr>
         			 <td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Simulation/Last%20Moment%20Before%20All%20Ants%20Fall%20Out%20of%20a%20Plank.cpp"> Last Moment Before All Ants Fall Out of a Plank (Leetcode-1503)</a>
				  </td>
      			</tr>
      			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Simulation/Find%20the%20Winner%20of%20an%20Array%20Game.cpp"> Find the Winner of an Array Game (Leetcode-1535)</a>
				</td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Simulation/Number%20of%20Students%20Unable%20to%20Eat%20Lunch.cpp"> Number of Students Unable to Eat Lunch (Leetcode-1700)</a>
				</td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Simulation/Average%20Waiting%20Time.cpp"> Average Waiting Time (Leetcode-1701)</a>
				</td>
      			</tr>
			<tr>
          			<td>
					  <a href="https://github.com/MAZHARMIK/Interview_DS_Algo/blob/master/Arrays/Simulation/Walking%20Robot%20Simulation.cpp"> Walking Robot Simulation (Leetcode-874)</a>
				</td>
      			</tr>
		</tbody>
</table>
